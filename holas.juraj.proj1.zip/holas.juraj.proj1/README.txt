Juraj Holas
Projekt c.1 -  Jednoduchy perceptron
Neuronove siete, 2014/2015

-> zdrojove subory k programu su v priecinku src/. Program nevyuziva ziadne
   externe kniznice ci balicky. Spusta sa hlavna trieda Main, bez argumentov.
-> v subore trainLog.txt je zaznamenany vystup z demonstracneho testovania
   perceptronu
-> v subore grafy.xlsx su vsetky zozbierane hrube data + z nich vygenerovane
   grafy
-> subor holas.juraj.proj1.pdf je pisomny report ku projektu, ktory bol
   odovzdany aj samostatne